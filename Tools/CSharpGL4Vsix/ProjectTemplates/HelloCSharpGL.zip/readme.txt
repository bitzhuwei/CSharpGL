﻿此项目是使用CSharpGL的入门教程。
详情参见（http://www.cnblogs.com/bitzhuwei/p/CSharpGL-1-start-from-a-simple-demo-with-legacy-modern-opengl.html）
