﻿此项目是使用CSharpGL的入门教程。
详情参见（http://www.cnblogs.com/bitzhuwei/p/CSharpGL-1-start-from-a-simple-demo-with-legacy-modern-opengl.html）
在项目文件夹下运行CSSL2GLSL.exe即可将Pyramid.cssl.cs转换为Pyramid.vert和Pyramid.frag
